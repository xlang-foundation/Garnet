// SPDX-FileCopyrightText: 2024-2026 CantorAI Inc.
// SPDX-License-Identifier: Apache-2.0

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include <cooperative_groups.h>
#include <stdio.h>
#include "cuda_lib.h"

namespace cg = cooperative_groups;

// ==============================================
// ͨ�ù��ߺ����ͳ�������
// ==============================================

constexpr int BLOCK_SIZE = 256;
constexpr int TILE_DIM = 32;

// ������������
__device__ int computeLinearIndex(int* dims, int dimCount, int* indices) {
    int index = 0;
    int stride = 1;
    for (int i = dimCount - 1; i >= 0; --i) {
        index += indices[i] * stride;
        stride *= dims[i];
    }
    return index;
}

// ==============================================
// ��Ԫ�س˷�ʵ��
// ==============================================


template <typename T>
__global__ void single_multiply_kernel(const T* A, const T* B, T* C, int count) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        // ��FP8����ʹ��ר��ת������
        if constexpr (std::is_same_v<T, __nv_fp8_e4m3>) {
            C[idx] = __nv_fp8_e4m3(float(A[idx]) * float(B[0]));
        }
        else if constexpr (std::is_same_v<T, __nv_fp8_e5m2>) {
            C[idx] = __nv_fp8_e5m2(float(A[idx]) * float(B[0]));
        }
        else {
            // �������ͱ���ԭת����ʽ
            C[idx] = T(float(A[idx]) * float(B[0]));
    }
    }
}


void runSingleElementTensorMultiplyFP32(float* multi, float* single, float* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_multiply_kernel<float> << <gridSize, BLOCK_SIZE >> > (multi, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorMultiplyFP16(__half* multi, __half* single, __half* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_multiply_kernel<__half> << <gridSize, BLOCK_SIZE >> > (multi, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorMultiplyBF16(__nv_bfloat16* multi, __nv_bfloat16* single, __nv_bfloat16* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_multiply_kernel<__nv_bfloat16> << <gridSize, BLOCK_SIZE >> > (multi, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorMultiplyFP8E4M3(__nv_fp8_e4m3* multi, __nv_fp8_e4m3* single, __nv_fp8_e4m3* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_multiply_kernel<__nv_fp8_e4m3> << <gridSize, BLOCK_SIZE >> > (multi, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorMultiplyFP8E5M2(__nv_fp8_e5m2* multi, __nv_fp8_e5m2* single, __nv_fp8_e5m2* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_multiply_kernel<__nv_fp8_e5m2> << <gridSize, BLOCK_SIZE >> > (multi, single, result, count);
    cudaDeviceSynchronize();
}

template <typename T>
__global__ void elementwise_multiply_kernel(const T* A, const T* B, T* C, int count) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        // ��FP8����ʹ��ר��ת������
        if constexpr (std::is_same_v<T, __nv_fp8_e4m3>) {
            C[idx] = __nv_fp8_e4m3(float(A[idx]) * float(B[idx]));
        }
        else if constexpr (std::is_same_v<T, __nv_fp8_e5m2>) {
            C[idx] = __nv_fp8_e5m2(float(A[idx]) * float(B[idx]));
        }
        else {
            // �������ͱ���ԭת����ʽ
            C[idx] = T(float(A[idx]) * float(B[idx]));
        }
    }
}


void runElementwiseTensorMultiplyFP8E4M3(__nv_fp8_e4m3* multi, __nv_fp8_e4m3* single, __nv_fp8_e4m3* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    elementwise_multiply_kernel<__nv_fp8_e4m3> << <gridSize, BLOCK_SIZE >> > (multi, single, result, count);
    cudaDeviceSynchronize();
}

void runElementwiseTensorMultiplyFP8E5M2(__nv_fp8_e5m2* multi, __nv_fp8_e5m2* single, __nv_fp8_e5m2* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    elementwise_multiply_kernel<__nv_fp8_e5m2> << <gridSize, BLOCK_SIZE >> > (multi, single, result, count);
    cudaDeviceSynchronize();
}

// ==============================================
// �����˷�ʵ��
// ==============================================

template <typename T>
__global__ void scalar_multiply_kernel(const T* input, T* result, float scalar, int count) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        result[idx] =T( float( input[idx]) * float(static_cast<T>(scalar)));
    }
}

void runScalarMultiplyFP32(float* input, float* result, float scalar, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    scalar_multiply_kernel<float> << <gridSize, BLOCK_SIZE >> > (input, result, scalar, count);
    cudaDeviceSynchronize();
}

void runScalarMultiplyFP16(__half* input, __half* result, float scalar, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    scalar_multiply_kernel<__half> << <gridSize, BLOCK_SIZE >> > (input, result, scalar, count);
    cudaDeviceSynchronize();
}

void runScalarMultiplyBF16(__nv_bfloat16* input, __nv_bfloat16* result, float scalar, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    scalar_multiply_kernel<__nv_bfloat16> << <gridSize, BLOCK_SIZE >> > (input, result, scalar, count);
    cudaDeviceSynchronize();
}

void runScalarMultiplyFP8E4M3(__nv_fp8_e4m3* input, __nv_fp8_e4m3* result, float scalar, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    scalar_multiply_kernel<__nv_fp8_e4m3> << <gridSize, BLOCK_SIZE >> > (input, result, scalar, count);
    cudaDeviceSynchronize();
}

void runScalarMultiplyFP8E5M2(__nv_fp8_e5m2* input, __nv_fp8_e5m2* result, float scalar, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    scalar_multiply_kernel<__nv_fp8_e5m2> << <gridSize, BLOCK_SIZE >> > (input, result, scalar, count);
    cudaDeviceSynchronize();
}

// ==============================================
// �ӷ�ʵ��
// ==============================================

template <typename T>
__global__ void add_kernel(const T* A, const T* B, T* C, int count) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        C[idx] =T(float( A[idx]) +float( B[idx]));
    }
}

void runAddFP64(double* A, double* B, double* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    add_kernel<double> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runAddFP32(float* A, float* B, float* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    add_kernel<float> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runAddFP16(__half* A, __half* B, __half* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    add_kernel<__half> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runAddBF16(__nv_bfloat16* A, __nv_bfloat16* B, __nv_bfloat16* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    add_kernel<__nv_bfloat16> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runAddFP8E4M3(__nv_fp8_e4m3* A, __nv_fp8_e4m3* B, __nv_fp8_e4m3* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    add_kernel<__nv_fp8_e4m3> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runAddFP8E5M2(__nv_fp8_e5m2* A, __nv_fp8_e5m2* B, __nv_fp8_e5m2* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    add_kernel<__nv_fp8_e5m2> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

// ==============================================
// ��Ԫ�������ӷ�ʵ��
// ==============================================

template <typename T>
__global__ void single_element_add_kernel(const T* tensor, T single, T* result, int count) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        result[idx] = T(float(tensor[idx]) + float(single));
    }
}

void runSingleElementTensorAddFP64(double* tensor, double single, double* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_add_kernel<double> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorAddFP32(float* tensor, float single, float* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_add_kernel<float> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorAddFP16(__half* tensor, __half single, __half* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_add_kernel<__half> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorAddBF16(__nv_bfloat16* tensor, __nv_bfloat16 single, __nv_bfloat16* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_add_kernel<__nv_bfloat16> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorAddFP8E4M3(__nv_fp8_e4m3* tensor, __nv_fp8_e4m3 single, __nv_fp8_e4m3* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_add_kernel<__nv_fp8_e4m3> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorAddFP8E5M2(__nv_fp8_e5m2* tensor, __nv_fp8_e5m2 single, __nv_fp8_e5m2* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_add_kernel<__nv_fp8_e5m2> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

// ==============================================
// �����ӷ�ʵ��
// ==============================================

template <typename T>
__global__ void scalar_add_kernel(const T* input, T* result, float scalar, int count) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        result[idx] = T(float(input[idx]) + scalar);
    }
}

void runScalarAddFP32(float* input, float scalar, float* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    scalar_add_kernel<float> << <gridSize, BLOCK_SIZE >> > (input, result, scalar, count);
    cudaDeviceSynchronize();
}

// ==============================================
// ����ʵ��
// ==============================================

template <typename T>
__global__ void minus_kernel(const T* A, const T* B, T* C, int count) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        C[idx] =T(float( A[idx]) - float(B[idx]));
    }
}

void runMinusFP64(double* A, double* B, double* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    minus_kernel<double> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runMinusFP32(float* A, float* B, float* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    minus_kernel<float> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runMinusFP16(__half* A, __half* B, __half* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    minus_kernel<__half> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runMinusBF16(__nv_bfloat16* A, __nv_bfloat16* B, __nv_bfloat16* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    minus_kernel<__nv_bfloat16> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runMinusFP8E4M3(__nv_fp8_e4m3* A, __nv_fp8_e4m3* B, __nv_fp8_e4m3* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    minus_kernel<__nv_fp8_e4m3> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

void runMinusFP8E5M2(__nv_fp8_e5m2* A, __nv_fp8_e5m2* B, __nv_fp8_e5m2* C, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    minus_kernel<__nv_fp8_e5m2> << <gridSize, BLOCK_SIZE >> > (A, B, C, count);
    cudaDeviceSynchronize();
}

// ==============================================
// ��Ԫ����������ʵ��
// ==============================================

template <typename T>
__global__ void single_element_minus_kernel(const T* tensor, T single, T* result, int count) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        result[idx] = T(float(tensor[idx]) - float(single));
    }
}

void runSingleElementTensorMinusFP64(double* tensor, double single, double* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_minus_kernel<double> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorMinusFP32(float* tensor, float single, float* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_minus_kernel<float> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorMinusFP16(__half* tensor, __half single, __half* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_minus_kernel<__half> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorMinusBF16(__nv_bfloat16* tensor, __nv_bfloat16 single, __nv_bfloat16* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_minus_kernel<__nv_bfloat16> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorMinusFP8E4M3(__nv_fp8_e4m3* tensor, __nv_fp8_e4m3 single, __nv_fp8_e4m3* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_minus_kernel<__nv_fp8_e4m3> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

void runSingleElementTensorMinusFP8E5M2(__nv_fp8_e5m2* tensor, __nv_fp8_e5m2 single, __nv_fp8_e5m2* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    single_element_minus_kernel<__nv_fp8_e5m2> << <gridSize, BLOCK_SIZE >> > (tensor, single, result, count);
    cudaDeviceSynchronize();
}

// ==============================================
// ��������ʵ��
// ==============================================

template <typename T>
__global__ void scalar_minus_kernel(const T* input, T scalar, T* result, int count) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        result[idx] = input[idx] - scalar;
    }
}

void runScalarMinusFP32(float* input, float scalar, float* result, int count) {
    int gridSize = (count + BLOCK_SIZE - 1) / BLOCK_SIZE;
    scalar_minus_kernel<float> << <gridSize, BLOCK_SIZE >> > (input, scalar, result, count);
    cudaDeviceSynchronize();
}

// ==============================================
// ����˷�(Matmul)ʵ��
// ==============================================

void runMatmulFP32(float* A, float* B, float* C, int m, int n, int k) {
    runGemmFP32(A, B, C, m, k, n);
}

void runMatmulFP16(__half* A, __half* B, __half* C, int m, int n, int k) {
    runGemmFP16(A, B, C, m, k, n);
}

void runMatmulBF16(__nv_bfloat16* A, __nv_bfloat16* B, __nv_bfloat16* C, int m, int n, int k) {
    runGemmBF16(A, B, C, m, k, n);
}

void runMatmulFP8E4M3(__nv_fp8_e4m3* A, __nv_fp8_e4m3* B, __nv_fp8_e4m3* C, int m, int n, int k) {
    runGemmFP8E4M3(A, B, C, m, k, n);
}

void runMatmulFP8E5M2(__nv_fp8_e5m2* A, __nv_fp8_e5m2* B, __nv_fp8_e5m2* C, int m, int n, int k) {
    runGemmFP8E5M2(A, B, C, m, k, n);
}

// ==============================================
// ת��(Permute)ʵ��
// ==============================================

template <typename T>
__global__ void permute_kernel(const T* input, T* output, int* permOrder, int* dimSizes, int dimCount, int totalElements) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= totalElements) return;

    // ����ԭʼ����
    int temp = idx;
    int originalCoords[8]; // ֧�����8ά����
    for (int i = dimCount - 1; i >= 0; --i) {
        originalCoords[i] = temp % dimSizes[i];
        temp /= dimSizes[i];
    }

    // ����ת�ú�����
    int transposedCoords[8];
    for (int i = 0; i < dimCount; ++i) {
        transposedCoords[i] = originalCoords[permOrder[i]];
    }

    // ����ת�ú���������
    int transposedIdx = 0;
    int stride = 1;
    for (int i = dimCount - 1; i >= 0; --i) {
        transposedIdx += transposedCoords[i] * stride;
        stride *= dimSizes[permOrder[i]];
    }

    output[transposedIdx] = input[idx];
}

void runPermuteFP32(float* input, float* output, int* permOrder, int* dimSizes, int dimCount) {
    int totalElements = 1;
    for (int i = 0; i < dimCount; ++i) {
        totalElements *= dimSizes[i];
    }

    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    permute_kernel<float> << <gridSize, BLOCK_SIZE >> > (input, output, permOrder, dimSizes, dimCount, totalElements);
    cudaDeviceSynchronize();
}

void runPermuteFP16(__half* input, __half* output, int* permOrder, int* dimSizes, int dimCount) {
    int totalElements = 1;
    for (int i = 0; i < dimCount; ++i) {
        totalElements *= dimSizes[i];
    }

    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    permute_kernel<__half> << <gridSize, BLOCK_SIZE >> > (input, output, permOrder, dimSizes, dimCount, totalElements);
    cudaDeviceSynchronize();
}

void runPermuteBF16(__nv_bfloat16* input, __nv_bfloat16* output, int* permOrder, int* dimSizes, int dimCount) {
    int totalElements = 1;
    for (int i = 0; i < dimCount; ++i) {
        totalElements *= dimSizes[i];
    }

    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    permute_kernel<__nv_bfloat16> << <gridSize, BLOCK_SIZE >> > (input, output, permOrder, dimSizes, dimCount, totalElements);
    cudaDeviceSynchronize();
}

void runPermuteFP8E4M3(__nv_fp8_e4m3* input, __nv_fp8_e4m3* output, int* permOrder, int* dimSizes, int dimCount) {
    int totalElements = 1;
    for (int i = 0; i < dimCount; ++i) {
        totalElements *= dimSizes[i];
    }

    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    permute_kernel<__nv_fp8_e4m3> << <gridSize, BLOCK_SIZE >> > (input, output, permOrder, dimSizes, dimCount, totalElements);
    cudaDeviceSynchronize();
}

void runPermuteFP8E5M2(__nv_fp8_e5m2* input, __nv_fp8_e5m2* output, int* permOrder, int* dimSizes, int dimCount) {
    int totalElements = 1;
    for (int i = 0; i < dimCount; ++i) {
        totalElements *= dimSizes[i];
    }

    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    permute_kernel<__nv_fp8_e5m2> << <gridSize, BLOCK_SIZE >> > (input, output, permOrder, dimSizes, dimCount, totalElements);
    cudaDeviceSynchronize();
}

// ==============================================
// Gather����ʵ��
// ==============================================

template <typename T>
__global__ void gather_kernel(const T* data, const int* indices, T* output,
    int* dataDims, int dataDimCount,
    int* indicesDims, int indicesDimCount, int dim) {

    // ����ÿ��������Ӧ��Ԫ������
    int elementsPerIndex = 1;
    for (int i = dim + 1; i < dataDimCount; ++i) {
        elementsPerIndex *= dataDims[i];
    }

    // ������������
    int totalIndices = 1;
    for (int i = 0; i < indicesDimCount; ++i) {
        totalIndices *= indicesDims[i];
    }

    // ÿ���̴߳���һ�����Ԫ��
    int index = blockIdx.x * blockDim.x + threadIdx.x;
    int element = blockIdx.y * blockDim.y + threadIdx.y;

    if (index < totalIndices && element < elementsPerIndex) {
        // ��ȡҪ�ռ�������
        int gatherIdx = indices[index];

        // ������������ƫ��
        int dataOffset = gatherIdx * elementsPerIndex + element;

        // �������λ��
        int outputOffset = index * elementsPerIndex + element;

        // ִ���ռ�����
        output[outputOffset] = data[dataOffset];
    }
}

void runGatherFP32(float* data, float* indices, float* output,
    int* dataDims, int dataDimCount,
    int* indicesDims, int indicesDimCount, int dim) {
    // ��������������ÿ��������Ӧ��Ԫ����
    int totalIndices = 1;
    for (int i = 0; i < indicesDimCount; ++i) {
        totalIndices *= indicesDims[i];
    }

    int elementsPerIndex = 1;
    for (int i = dim + 1; i < dataDimCount; ++i) {
        elementsPerIndex *= dataDims[i];
    }

    // �����ں���������
    dim3 block(16, 16);
    dim3 grid((totalIndices + block.x - 1) / block.x,
        (elementsPerIndex + block.y - 1) / block.y);

    gather_kernel<float> << <grid, block >> > (
        data, (int*)indices, output,
        dataDims, dataDimCount,
        indicesDims, indicesDimCount, dim);

    cudaDeviceSynchronize();
}

void runGatherFP16(__half* data, __half* indices, __half* output,
    int* dataDims, int dataDimCount,
    int* indicesDims, int indicesDimCount, int dim) {
    int totalIndices = 1;
    for (int i = 0; i < indicesDimCount; ++i) {
        totalIndices *= indicesDims[i];
    }

    int elementsPerIndex = 1;
    for (int i = dim + 1; i < dataDimCount; ++i) {
        elementsPerIndex *= dataDims[i];
    }

    dim3 block(16, 16);
    dim3 grid((totalIndices + block.x - 1) / block.x,
        (elementsPerIndex + block.y - 1) / block.y);

    gather_kernel<__half> << <grid, block >> > (
        data, (int*)indices, output,
        dataDims, dataDimCount,
        indicesDims, indicesDimCount, dim);

    cudaDeviceSynchronize();
}

void runGatherBF16(__nv_bfloat16* data, int* indices, __nv_bfloat16* output,
    int* dataDims, int dataDimCount,
    int* indicesDims, int indicesDimCount, int dim) {
    int totalIndices = 1;
    for (int i = 0; i < indicesDimCount; ++i) {
        totalIndices *= indicesDims[i];
    }

    int elementsPerIndex = 1;
    for (int i = dim + 1; i < dataDimCount; ++i) {
        elementsPerIndex *= dataDims[i];
    }

    dim3 block(16, 16);
    dim3 grid((totalIndices + block.x - 1) / block.x,
        (elementsPerIndex + block.y - 1) / block.y);

    gather_kernel<__nv_bfloat16> << <grid, block >> > (
        data, indices, output,
        dataDims, dataDimCount,
        indicesDims, indicesDimCount, dim);

    cudaDeviceSynchronize();
}

void runGatherFP8E4M3(__nv_fp8_e4m3* data, __nv_fp8_e4m3* indices, __nv_fp8_e4m3* output,
    int* dataDims, int dataDimCount,
    int* indicesDims, int indicesDimCount, int dim) {
    int totalIndices = 1;
    for (int i = 0; i < indicesDimCount; ++i) {
        totalIndices *= indicesDims[i];
    }

    int elementsPerIndex = 1;
    for (int i = dim + 1; i < dataDimCount; ++i) {
        elementsPerIndex *= dataDims[i];
    }

    dim3 block(16, 16);
    dim3 grid((totalIndices + block.x - 1) / block.x,
        (elementsPerIndex + block.y - 1) / block.y);

    gather_kernel<__nv_fp8_e4m3> << <grid, block >> > (
        data, (int*)indices, output,
        dataDims, dataDimCount,
        indicesDims, indicesDimCount, dim);

    cudaDeviceSynchronize();
}

void runGatherFP8E5M2(__nv_fp8_e5m2* data, __nv_fp8_e5m2* indices, __nv_fp8_e5m2* output,
    int* dataDims, int dataDimCount,
    int* indicesDims, int indicesDimCount, int dim) {
    int totalIndices = 1;
    for (int i = 0; i < indicesDimCount; ++i) {
        totalIndices *= indicesDims[i];
    }

    int elementsPerIndex = 1;
    for (int i = dim + 1; i < dataDimCount; ++i) {
        elementsPerIndex *= dataDims[i];
    }

    dim3 block(16, 16);
    dim3 grid((totalIndices + block.x - 1) / block.x,
        (elementsPerIndex + block.y - 1) / block.y);

    gather_kernel<__nv_fp8_e5m2> << <grid, block >> > (
        data, (int*)indices, output,
        dataDims, dataDimCount,
        indicesDims, indicesDimCount, dim);

    cudaDeviceSynchronize();
}

// ==============================================
// ����ת��ʵ��
// ==============================================

__global__ void convert_fp32_to_fp16_kernel(float* src, __half* dest, int totalElements) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < totalElements) {
        dest[idx] = __float2half(src[idx]);
    }
}

void runConvertFP32ToFP16(float* src, __half* dest, int totalElements) {
    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    convert_fp32_to_fp16_kernel << <gridSize, BLOCK_SIZE >> > (src, dest, totalElements);
    cudaDeviceSynchronize();
}

__global__ void convert_fp32_to_bf16_kernel(float* src, __nv_bfloat16* dest, int totalElements) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < totalElements) {
        dest[idx] = __float2bfloat16(src[idx]);
    }
}

void runConvertFP32ToBF16(float* src, __nv_bfloat16* dest, int totalElements) {
    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    convert_fp32_to_bf16_kernel << <gridSize, BLOCK_SIZE >> > (src, dest, totalElements);
    cudaDeviceSynchronize();
}

__global__ void convert_fp32_to_fp8e4m3_kernel(float* src, __nv_fp8_e4m3* dest, int totalElements) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < totalElements) {
        //dest[idx] = __float2nv_fp8_e4m3(src[idx]);
        dest[idx] = (__nv_fp8_e4m3)__nv_cvt_float_to_fp8(src[idx], __NV_SATFINITE, __NV_E4M3);
    }
}

void runConvertFP32ToFP8E4M3(float* src, __nv_fp8_e4m3* dest, int totalElements) {
    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    convert_fp32_to_fp8e4m3_kernel << <gridSize, BLOCK_SIZE >> > (src, dest, totalElements);
    cudaDeviceSynchronize();
}

__global__ void convert_fp32_to_fp8e5m2_kernel(float* src, __nv_fp8_e5m2* dest, int totalElements) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < totalElements) {
        //dest[idx] = __float2nv_fp8_e5m2(src[idx]);
        dest[idx] = (__nv_fp8_e5m2)__nv_cvt_float_to_fp8(src[idx], __NV_SATFINITE, __NV_E5M2);
    }
}

void runConvertFP32ToFP8E5M2(float* src, __nv_fp8_e5m2* dest, int totalElements) {
    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    convert_fp32_to_fp8e5m2_kernel << <gridSize, BLOCK_SIZE >> > (src, dest, totalElements);
    cudaDeviceSynchronize();
}

__global__ void convert_fp16_to_fp32_kernel(__half* src, float* dest, int totalElements) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < totalElements) {
        dest[idx] = __half2float(src[idx]);
    }
}

void runConvertFP16ToFP32(__half* src, float* dest, int totalElements) {
    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    convert_fp16_to_fp32_kernel << <gridSize, BLOCK_SIZE >> > (src, dest, totalElements);
    cudaDeviceSynchronize();
}

__global__ void convert_bf16_to_fp32_kernel(__nv_bfloat16* src, float* dest, int totalElements) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < totalElements) {
        dest[idx] = __bfloat162float(src[idx]);
    }
}

void runConvertBF16ToFP32(__nv_bfloat16* src, float* dest, int totalElements) {
    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    convert_bf16_to_fp32_kernel << <gridSize, BLOCK_SIZE >> > (src, dest, totalElements);
    cudaDeviceSynchronize();
}

__global__ void convert_fp8e4m3_to_fp32_kernel(__nv_fp8_e4m3* src, float* dest, int totalElements) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < totalElements) {
        //dest[idx] = __nv_fp8e4m32float(src[idx]);
#if defined(__CUDA_FP8_TYPES_EXIST__)
        dest[idx] = float(__nv_fp8_e4m3(src[idx]));  // ��ʽ�����ת��
#else
        return 0.0f;
#endif
    }
}

void runConvertFP8E4M3ToFP32(__nv_fp8_e4m3* src, float* dest, int totalElements) {
    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    convert_fp8e4m3_to_fp32_kernel << <gridSize, BLOCK_SIZE >> > (src, dest, totalElements);
    cudaDeviceSynchronize();
}

__global__ void convert_fp8e5m2_to_fp32_kernel(__nv_fp8_e5m2* src, float* dest, int totalElements) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < totalElements) {
       // dest[idx] = __nv_fp8e5m22float(src[idx]);        
#if defined(__CUDA_FP8_TYPES_EXIST__)
        dest[idx] = float(__nv_fp8_e5m2(src[idx]));  // ��ʽ�����ת��
#else
        return 0.0f;
#endif
    }
}

void runConvertFP8E5M2ToFP32(__nv_fp8_e5m2* src, float* dest, int totalElements) {
    int gridSize = (totalElements + BLOCK_SIZE - 1) / BLOCK_SIZE;
    convert_fp8e5m2_to_fp32_kernel << <gridSize, BLOCK_SIZE >> > (src, dest, totalElements);
    cudaDeviceSynchronize();
}

// ------------------------
// Memory Management
// ------------------------
void runZeroInitializeFP32(float* data, int count, cudaStream_t stream) {
    cudaError_t err = cudaMemsetAsync(data, 0, count * sizeof(float), stream);
    assert(err == cudaSuccess);
}

void runZeroInitializeFP16(__half* data, int count, cudaStream_t stream) {
    cudaError_t err = cudaMemsetAsync(data, 0, count * sizeof(__half), stream);
    assert(err == cudaSuccess);
}

void runZeroInitializeBF16(bfloat16* data, int count, cudaStream_t stream) {
    cudaError_t err = cudaMemsetAsync(data, 0, count * sizeof(bfloat16), stream);
    assert(err == cudaSuccess);
}

//#ifdef _WIN32
//static class Cleanup {
//public:
//    ~Cleanup() {
//        CublasHandle::destroy();
//    }
//} 
//#else
//__attribute__((destructor))
//static void cleanup() {
//    CublasHandle::destroy();
//}
//#endif