# SPDX-License-Identifier: Apache-2.0
"""Bounded CUDA decoder chunk, also used for padded single-token decode.

Each layer has one compiled engine/weight set. BF16 input/output projections
and MLPs span the chunk; recurrent state evolves in token order on the GPU.
The existing Metal and serial TE programs are unchanged.
"""
from .tensor_compat import tensor
T=tensor()

@T.fusion(name='qwen35_cuda_decoder_chunk',role='decoder_layer',boundary='required')
def Qwen35CUDAChunk(hidden,state1,state2,active,positions,slots,config,layer_idx,kind,fused_delta=False,fused_attention=False,projection_workspace_bytes=0,retain_linear_inputs=False,external_weights=None,register_delta_128=False,join_input_projections=False,external_compressed_weights=None,joined_mlp_projections=False,canonical_kv_state=None,canonical_kv_layout=None,kv_overlay_strategy=1,bf16_canonical_kv=False,bf16_kv_float_reference=False,bf16_low_batch_canonical_kv=False,bf16_prefill128_canonical_kv=False):
    p='model.language_model.layers.'+str(layer_idx)
    extra={'external_weights':external_weights} if external_weights else {}
    if external_compressed_weights:extra['external_compressed_weights']=external_compressed_weights
    if type(bf16_prefill128_canonical_kv) is not bool or (bf16_prefill128_canonical_kv and (bf16_low_batch_canonical_kv or bf16_canonical_kv or bf16_kv_float_reference or canonical_kv_state is None or kind!="full_attention")):
        raise ValueError("T128 BF16 canonical KV requires its separate exclusive full-attention binding")
    if type(bf16_low_batch_canonical_kv) is not bool or (bf16_low_batch_canonical_kv and (bf16_canonical_kv or bf16_kv_float_reference or canonical_kv_state is None)):
        raise ValueError("B1 BF16 canonical KV requires its own exclusive explicit binding")
    if type(bf16_kv_float_reference) is not bool or (bf16_kv_float_reference and (kind!='full_attention' or canonical_kv_state is not None or bf16_canonical_kv or state1 is None or state2 is None)):
        raise ValueError('BF16 float reference requires ordinary full-attention cache bindings')
    if bf16_kv_float_reference:extra['bf16_kv_float_reference']=1
    if type(bf16_canonical_kv) is not bool or (bf16_canonical_kv and canonical_kv_state is None):raise ValueError('BF16 canonical KV requires an explicit full-attention binding')
    if canonical_kv_state is not None and (kind!='full_attention' or canonical_kv_layout is None or state1 is not None or state2 is not None):
        raise ValueError('Canonical KV requires only the full-attention packed-state binding')
    if kind=='linear_attention':
        bound=hidden*T.binary_op('qwen35_conv_bind_state')*state1
        bound=bound*T.binary_op('qwen35_delta_bind_state')*state2
        bound=bound*T.binary_op('qwen35_conv_bind_active')*active
        return bound*T.unary_op('qwen35_linear_decoder_chunk',layer_prefix=p,
            key_heads=config['linear_num_key_heads'],value_heads=config['linear_num_value_heads'],
            key_dim=config['linear_key_head_dim'],value_dim=config['linear_value_head_dim'],eps=config['rms_norm_eps'],fused_delta=int(fused_delta),projection_workspace_bytes=projection_workspace_bytes,retain_linear_inputs=int(retain_linear_inputs),register_delta_128=int(register_delta_128),joined_input_projections=int(join_input_projections),joined_mlp_projections=int(joined_mlp_projections),**extra)
    if canonical_kv_state is not None:
        bound=hidden*T.binary_op('qwen35_attention_bind_canonical')*canonical_kv_state
        extra.update({('canonical_bf16_prefill128_kv_overlay' if bf16_prefill128_canonical_kv else ('canonical_bf16_low_batch_kv_overlay' if bf16_low_batch_canonical_kv else ('canonical_bf16_kv_overlay' if bf16_canonical_kv else 'canonical_kv_overlay'))):1})
        extra.update(kv_overlay_strategy=kv_overlay_strategy,
            canonical_state_width=canonical_kv_layout['cache_batch_stride'],canonical_key_offset=canonical_kv_layout['key_offset'],canonical_value_offset=canonical_kv_layout['value_offset'])
    else:
        bound=hidden*T.binary_op('qwen35_attention_bind_key')*state1
        bound=bound*T.binary_op('qwen35_attention_bind_value')*state2
    bound=bound*T.binary_op('qwen35_attention_bind_positions')*positions
    bound=bound*T.binary_op('qwen35_attention_bind_slots')*slots
    bound=bound*T.binary_op('qwen35_attention_bind_active')*active
    rope=config['rope_parameters']
    return bound*T.unary_op('qwen35_full_decoder_chunk',layer_prefix=p,
        num_heads=config['num_attention_heads'],num_kv_heads=config['num_key_value_heads'],head_dim=config['head_dim'],
        rotary_dim=int(config['head_dim']*rope['partial_rotary_factor']),rope_theta=rope['rope_theta'],
        mrope_t=rope['mrope_section'][0],mrope_h=rope['mrope_section'][1],mrope_w=rope['mrope_section'][2],eps=config['rms_norm_eps'],fused_attention=int(fused_attention),projection_workspace_bytes=projection_workspace_bytes,joined_mlp_projections=int(joined_mlp_projections),**extra)
