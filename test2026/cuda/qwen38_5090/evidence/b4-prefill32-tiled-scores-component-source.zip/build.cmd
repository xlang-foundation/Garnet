@echo off
setlocal
call "%~1" -vcvars_ver=14.44
if errorlevel 1 exit /b %errorlevel%
where cl
if errorlevel 1 exit /b %errorlevel%
"D:\CantorAI\5090-study-20261023\tools\cuda13\nvidia\cu13\bin\nvcc.exe" --std=c++17 -O3 --gpu-architecture=sm_120 --cudart=static --fmad=true --prec-div=true --prec-sqrt=true -Xcompiler=/MT,/O2,/EHsc -I "%~2" "%~2\probe_b4_prefill32_tiled_scores.cu" "%~2\qwen38_bf16_kv_overlay.cu" "%~2\qwen38_bf16_prefill32_tiled_scores.cu" -o "%~3"
exit /b %errorlevel%
