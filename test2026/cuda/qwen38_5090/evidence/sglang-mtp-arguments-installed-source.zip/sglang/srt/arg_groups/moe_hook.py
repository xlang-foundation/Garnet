# SPDX-License-Identifier: Apache-2.0
"""Server-argument resolution for the MoE kernel configuration."""

from __future__ import annotations

import logging
import os
from typing import Any

from sglang.srt.arg_groups.overrides import (
    _a2a_backend_overrides,
    _a2a_ep_size,
    _a2a_fusion_adjustments,
    _moe_runner_backend_quant_constraints,
    _moe_runner_fusion_disable,
    declare_resolution,
    flashinfer_a2a_max_dispatch_tokens_per_rank,
    max_prefill_buffer_tokens,
    max_speculative_num_draft_tokens,
    model_config_of,
    resolved_view,
    resolving_view,
    run_post_process_pass,
)
from sglang.srt.configs.moe_model_registry import (
    model_deepep_v2_prefill_dispatch_tokens,
    model_supports_deepep_v2,
)
from sglang.srt.connector import ConnectorType
from sglang.srt.environ import envs
from sglang.srt.model_executor.cuda_graph_config import Backend, Phase, with_phase
from sglang.srt.runtime_context import attn_dp_enabled_of, get_platform
from sglang.srt.utils.common import (
    get_bool_env_var,
    is_gfx1250_supported,
    is_sm100_supported,
    parse_connector_type,
)

logger = logging.getLogger(__name__)


def handle_moe_kernel_config(server_args: Any):
    # The quantization-driven runner resolutions moved to the pipeline
    # (arg_groups/overrides.py: _moe_runner_backend_quant_constraints);
    # the compatibility asserts and fusion writes stay below.

    cfg = resolving_view(server_args)

    run_post_process_pass(server_args, _moe_runner_backend_quant_constraints)

    view = resolved_view(server_args)
    if view.moe_runner_backend == "flashinfer_cutlass":
        assert view.quantization in [
            "modelopt_fp4",
            "modelopt_fp8",
            "modelopt_mixed",
            None,
        ], (
            f"Invalid quantization '{view.quantization}'. \nFlashInfer Cutlass MOE supports only: 'modelopt_fp4', 'modelopt_fp8', 'modelopt_mixed', or bfloat16 (None)."
        )
        assert view.ep_size in [
            1,
            cfg.tp_size,
        ], "The expert parallel size must be 1 or the same as the tensor parallel size"

    if view.moe_runner_backend == "flashinfer_cutedsl":
        # modelopt_mixed with non-NVFP4 MoE layers is rejected at load time.
        assert (
            view.quantization in ["modelopt_fp4", "modelopt_mixed", "nvfp4_online"]
            or model_config_of(server_args).nvfp4_moe_meta is not None
        ), (
            f"Invalid quantization '{view.quantization}'. \nFlashInfer CuteDSL MOE currently supports only: 'modelopt_fp4', 'modelopt_mixed' (with NVFP4 MoE layers), 'nvfp4_online', or hybrid NVFP4 models."
        )
        assert view.ep_size in [
            1,
            cfg.tp_size,
        ], "The expert parallel size must be 1 or the same as the tensor parallel size"
        assert view.moe_a2a_backend in [
            "none",
            "deepep",
            "flashinfer",
        ], (
            f"flashinfer_cutedsl supports moe_a2a_backend='none', 'deepep', or 'flashinfer', "
            f"got '{view.moe_a2a_backend}'."
        )
        if view.moe_a2a_backend == "deepep" and (
            view.quantization == "nvfp4_online"
            or envs.SGLANG_FLASHINFER_NVFP4_PER_TOKEN_ACTIVATION.get()
        ):
            raise ValueError(
                "flashinfer_cutedsl per-token NVFP4 activation requires "
                "moe_a2a_backend='none' or 'flashinfer'."
            )

    if view.moe_runner_backend in ["flashinfer_trtllm", "experimental_sgl_trtllm"]:
        assert view.quantization in [
            "modelopt_fp4",
            "nvfp4_online",
            "fp8",
            "mxfp8",
            "modelopt_fp8",
            "modelopt_mixed",
            "compressed-tensors",
            None,
        ], (
            f"Invalid quantization '{view.quantization}'. \nFlashInfer TRTLLM MOE supports only: 'modelopt_fp4', 'nvfp4_online', 'fp8', 'modelopt_fp8', 'modelopt_mixed', 'compressed-tensors', or bfloat16 (None)."
        )

    if view.moe_runner_backend == "flashinfer_trtllm_routed":
        assert view.quantization in [
            "fp8",
            "mxfp8",
            "modelopt_fp4",
            "modelopt_mixed",
            "nvfp4_online",
            None,
        ], (
            f"Invalid quantization '{view.quantization}'. \nFlashInfer TRTLLM routed MOE supports only: 'fp8', 'mxfp8', 'modelopt_fp4', 'modelopt_mixed', 'nvfp4_online', or bfloat16 (None)."
        )

    # The runner-driven shared-experts fusion disables moved to the
    # pipeline (arg_groups/overrides.py: _moe_runner_fusion_disable),
    # invoked here at the legacy write slots.
    run_post_process_pass(server_args, _moe_runner_fusion_disable)

    if resolved_view(server_args).moe_runner_backend == "cutlass" and resolved_view(
        server_args
    ).quantization in [
        "fp8",
        "mxfp8",
    ]:
        assert resolved_view(server_args).ep_size == 1, (
            "FP8/MXFP8 Cutlass MoE is only supported with ep_size == 1"
        )


def handle_flashinfer_a2a_dispatch_type(server_args: Any):
    cfg = resolving_view(server_args)
    cli_dispatch_type = cfg.flashinfer_a2a_dispatch_type
    nvfp4_dispatch_env_is_set = envs.SGLANG_MOE_NVFP4_DISPATCH.is_set()

    if nvfp4_dispatch_env_is_set:
        raise ValueError(
            "SGLANG_MOE_NVFP4_DISPATCH cannot be set together with "
            "--flashinfer-a2a-dispatch-type."
        )

    dispatch_type = cli_dispatch_type or "auto"

    supports_nvfp4_dispatch = (
        cfg.quantization == "modelopt_fp4"
        or model_config_of(server_args).nvfp4_moe_meta is not None
    )
    if dispatch_type == "auto":
        if cfg.quantization == "mxfp8":
            dispatch_type = "mxfp8"
        elif supports_nvfp4_dispatch:
            dispatch_type = "nvfp4"
        else:
            dispatch_type = "bf16"

    if dispatch_type == "mxfp8":
        if cfg.quantization != "mxfp8":
            raise ValueError(
                "--flashinfer-a2a-dispatch-type mxfp8 requires --quantization mxfp8."
            )
        if cfg.moe_runner_backend != "flashinfer_trtllm_routed":
            raise ValueError(
                "--flashinfer-a2a-dispatch-type mxfp8 requires "
                "--moe-runner-backend flashinfer_trtllm_routed."
            )
    elif dispatch_type == "nvfp4" and not supports_nvfp4_dispatch:
        raise ValueError(
            "--flashinfer-a2a-dispatch-type nvfp4 requires NVFP4/"
            "modelopt-FP4 quantization or hybrid NVFP4 MoE metadata."
        )

    declare_resolution(
        server_args,
        "_handle_flashinfer_a2a_dispatch_type",
        flashinfer_a2a_dispatch_type=dispatch_type,
    )


def validate_flashinfer_megamoe_envs() -> None:
    combine_dtype = envs.SGLANG_FLASHINFER_MEGAMOE_COMBINE_DTYPE.get().strip().lower()
    if combine_dtype not in ("bf16", "mxfp8", "nvfp4"):
        raise ValueError(
            "SGLANG_FLASHINFER_MEGAMOE_COMBINE_DTYPE must be one of "
            f"'bf16', 'mxfp8', or 'nvfp4', got {combine_dtype!r}."
        )
    if (
        combine_dtype != "bf16"
        and envs.SGLANG_FLASHINFER_MEGAMOE_IN_KERNEL_FC2_REDUCE.get()
    ):
        raise ValueError(
            "SGLANG_FLASHINFER_MEGAMOE_COMBINE_DTYPE="
            f"{combine_dtype!r} is incompatible with "
            "SGLANG_FLASHINFER_MEGAMOE_IN_KERNEL_FC2_REDUCE=1."
        )


def validate_flashinfer_megamoe_model(server_args: Any) -> None:
    model_config = model_config_of(server_args)
    architectures = model_config.hf_config.architectures or []
    validated_architectures = (
        "DeepseekV2ForCausalLM",
        "DeepseekV3ForCausalLM",
        "DeepseekV32ForCausalLM",
        "DeepseekV4ForCausalLM",
        "Glm4MoeForCausalLM",
        "GlmMoeDsaForCausalLM",
        "NemotronHForCausalLM",
        "NemotronHPuzzleForCausalLM",
        "Qwen2MoeForCausalLM",
        "Qwen3MoeForCausalLM",
    )
    if not any(
        architecture in validated_architectures for architecture in architectures
    ):
        raise ValueError(
            "FlashInfer MegaMOE is not validated for model architectures "
            f"{architectures}. Supported architectures: "
            f"{sorted(validated_architectures)}."
        )

    quantization = resolved_view(server_args).quantization
    supports_megamoe_quantization = (
        quantization in ("mxfp8", "modelopt_fp4")
        or model_config.is_fp4_experts
        or model_config.nvfp4_moe_meta is not None
    )
    if not supports_megamoe_quantization:
        raise ValueError(
            "FlashInfer MegaMOE currently supports only MXFP8, ModelOpt "
            "NVFP4, FP4-expert, or hybrid NVFP4 MoE checkpoints; got "
            f"quantization={quantization!r}. Standard FP8 MoE checkpoints "
            "are not supported."
        )


def handle_a2a_moe(server_args: Any):
    # The backend overrides and the ep_size=tp_size adjustments moved to
    # the resolution pipeline (arg_groups/overrides.py:
    # _a2a_backend_overrides / _a2a_ep_size); the per-backend logs,
    # asserts, fusion/deepep_mode/env/cuda-graph writes stay below.

    cfg = resolving_view(server_args)

    run_post_process_pass(server_args, _a2a_backend_overrides)
    run_post_process_pass(server_args, _a2a_ep_size)

    # The a2a-driven shared-experts fusion adjustments moved to the
    # pipeline (arg_groups/overrides.py: _a2a_fusion_adjustments),
    # invoked here at the legacy write slots.
    run_post_process_pass(server_args, _a2a_fusion_adjustments)

    a2a_backend = resolved_view(server_args).moe_a2a_backend
    if cfg.enable_waterfill:
        declare_resolution(
            server_args, "_handle_a2a_moe", enforce_shared_experts_fusion=True
        )
        logger.info(f"Waterfill is enabled with moe_a2a_backend='{a2a_backend}'.")

    if a2a_backend != "flashinfer" and cfg.flashinfer_a2a_dispatch_type not in (
        None,
        "auto",
    ):
        raise ValueError(
            "--flashinfer-a2a-dispatch-type requires --moe-a2a-backend flashinfer."
        )

    if a2a_backend == "flashinfer_megamoe":
        validate_flashinfer_megamoe_model(server_args)
        validate_flashinfer_megamoe_envs()
        assert attn_dp_enabled_of(cfg) and cfg.attn_dp_size == cfg.tp_size, (
            "FlashInfer MegaMOE is only supported with --attn-dp-size equal to --tp-size"
        )
        if resolved_view(server_args).moe_runner_backend == "auto":
            declare_resolution(
                server_args, "_handle_a2a_moe", moe_runner_backend="flashinfer_megamoe"
            )
        assert resolved_view(server_args).moe_runner_backend == "flashinfer_megamoe", (
            "FlashInfer MegaMOE a2a backend requires --moe-runner-backend flashinfer_megamoe"
        )
        if not is_sm100_supported():
            raise ValueError(
                "FlashInfer MegaMOE currently requires an SM100-family "
                "CUDA device for all supported quantization formats."
            )
        logger.info(
            "FlashInfer MegaMOE is enabled. The expert parallel size is "
            "adjusted to be the same as the tensor parallel size[%s].",
            cfg.tp_size,
        )

    if a2a_backend == "deepep":
        if cfg.moe_runner_backend == "flashinfer_cutedsl":
            if cfg.deepep_mode == "auto":
                declare_resolution(
                    server_args,
                    "_handle_a2a_moe",
                    deepep_mode="low_latency",
                )
                logger.warning(
                    "Forcing --deepep-mode low_latency: flashinfer_cutedsl "
                    "FP4 MoE has no DeepEP normal-dispatch handler, so "
                    "deepep auto mode would crash during prefill. "
                    "low_latency covers both prefill and decode."
                )
            elif cfg.deepep_mode == "normal":
                raise ValueError(
                    "flashinfer_cutedsl FP4 MoE only supports DeepEP "
                    "low_latency dispatch (masked layout). DeepEP normal "
                    "(prefill) dispatch has no CuteDSL FP4 handler. Pass "
                    "--deepep-mode low_latency or auto."
                )
        if cfg.deepep_mode == "normal":
            logger.warning("Cuda graph is disabled because deepep_mode=`normal`")
            declare_resolution(
                server_args,
                "_handle_a2a_moe",
                cuda_graph_config=with_phase(
                    cfg.cuda_graph_config, Phase.DECODE, backend=Backend.DISABLED
                ),
            )
            declare_resolution(
                server_args,
                "_handle_a2a_moe",
                cuda_graph_config=with_phase(
                    cfg.cuda_graph_config, Phase.PREFILL, backend=Backend.DISABLED
                ),
            )

    if a2a_backend == "deepep_v2":
        validate_deepep_v2_model_architecture(server_args)
        # ElasticBuffer requires CUMEM, but not NVLS or its preallocation.
        os.environ.setdefault("NCCL_CUMEM_ENABLE", "1")
        # Respect model-level runner declarations before resolving auto.
        resolved_runner = resolved_view(server_args).moe_runner_backend
        if resolved_runner == "auto":
            declare_resolution(
                server_args, "_handle_a2a_moe", moe_runner_backend="deep_gemm"
            )
            logger.warning(
                "DeepEP v2 MoE: resolved --moe-runner-backend auto -> deep_gemm."
            )
        elif resolved_runner != "deep_gemm":
            raise ValueError(
                "DeepEP v2 MoE currently supports only "
                f"--moe-runner-backend deep_gemm. Got {resolved_runner!r}. "
                "Add a runner adapter before enabling DeepEP v2 with other "
                "MoE runners."
            )
        if cfg.enable_two_batch_overlap or cfg.enable_single_batch_overlap:
            raise ValueError(
                "DeepEP v2 MoE has not implemented the TBO/SBO overlap hooks yet. "
                "Disable --enable-two-batch-overlap and "
                "--enable-single-batch-overlap when using --moe-a2a-backend deepep_v2."
            )
        if cfg.enforce_shared_experts_fusion:
            raise ValueError(
                "DeepEP v2 MoE has not validated fused shared experts yet. "
                "Remove --enforce-shared-experts-fusion when using "
                "--moe-a2a-backend deepep_v2."
            )
        if cfg.deepep_v2_mode == "direct" and cfg.nnodes > 1:
            raise ValueError(
                "--deepep-v2-mode direct is NVLink-only and cannot run across "
                f"nodes (nnodes={cfg.nnodes}); pass --deepep-v2-mode hybrid."
            )
        # Prefill reads host counts and is not graph-capturable.
        declare_resolution(
            server_args,
            "_handle_a2a_moe",
            cuda_graph_config=with_phase(
                cfg.cuda_graph_config, Phase.PREFILL, backend=Backend.DISABLED
            ),
        )
        logger.warning(
            f"DeepEP v2 MoE is enabled. The expert parallel size is adjusted to be the same as the tensor parallel size[{cfg.tp_size}]."
        )
        logger.warning(
            "DeepEP v2 MoE is using deepep_v2_mode=%s. This controls "
            "ElasticBuffer direct/hybrid mode and is independent from "
            "--deepep-mode normal/low_latency. DeepEP v2 MoE enables the "
            "decode CUDA graph on the masked decode path (any comm mode) "
            "and disables shared expert fusion. "
            "SGLANG_DEEPEP_V2_NUM_MAX_DISPATCH_TOKENS_PER_RANK is a "
            "per-rank communication buffer capacity, not a model limit; "
            "increase it for large prefill/chunked-prefill workloads.",
            cfg.deepep_v2_mode,
        )

    # The resolving view, not the field: `_a2a_backend_overrides` may have
    # moved this already (waterfill forces `deepep`).
    a2a_now = resolved_view(server_args).moe_a2a_backend
    if (a2a_now == "none" and get_platform().is_npu) or a2a_now == "ascend_tp":
        # FIXME (OrangeRedeng): for some reasons if pass "ascend_tp" accuracy drops to zero
        declare_resolution(
            server_args,
            "_handle_a2a_moe",
            moe_a2a_backend="none",
        )

    if a2a_now == "flashinfer":
        assert attn_dp_enabled_of(cfg) and cfg.attn_dp_size == cfg.tp_size, (
            "Flashinfer MoE A2A is only supported with --attn-dp-size equal to --tp-size"
        )
        if cfg.deepep_mode != "auto":
            logger.warning("--deepep-mode is ignored for Flashinfer MoE A2A")
        use_cutedsl_w4a16 = (
            resolved_view(server_args).moe_runner_backend == "flashinfer_cutedsl"
            and envs.SGLANG_FLASHINFER_CUTEDSL_NVFP4_W4A16.get()
        )
        if use_cutedsl_w4a16 and envs.SGLANG_MOE_NVFP4_DISPATCH.get():
            raise ValueError(
                "CuTe DSL NVFP4 W4A16 requires BF16 FlashInfer MoE "
                "dispatch; unset SGLANG_MOE_NVFP4_DISPATCH."
            )
        if cfg.flashinfer_a2a_dispatch_type is None:
            if (
                not use_cutedsl_w4a16
                and not envs.SGLANG_MOE_NVFP4_DISPATCH.is_set()
                and (
                    resolved_view(server_args).quantization == "modelopt_fp4"
                    or model_config_of(server_args).nvfp4_moe_meta is not None
                )
            ):
                envs.SGLANG_MOE_NVFP4_DISPATCH.set(True)
                logger.warning(
                    "SGLANG_MOE_NVFP4_DISPATCH is set to True for Flashinfer MoE A2A"
                )
        else:
            if resolved_view(server_args).moe_runner_backend == "flashinfer_trtllm":
                declare_resolution(
                    server_args,
                    "_handle_a2a_moe",
                    moe_runner_backend="flashinfer_trtllm_routed",
                )
                logger.warning(
                    "Flashinfer MoE A2A is enabled with flashinfer_trtllm. "
                    "Using flashinfer_trtllm_routed because A2A dispatch "
                    "provides top-k ids and weights."
                )
            if use_cutedsl_w4a16 and cfg.flashinfer_a2a_dispatch_type in (
                "auto",
                "nvfp4",
            ):
                raise ValueError(
                    "CuTe DSL NVFP4 W4A16 requires --flashinfer-a2a-dispatch-type bf16."
                )
            handle_flashinfer_a2a_dispatch_type(server_args)
        assert resolved_view(server_args).moe_runner_backend in [
            "flashinfer_cutlass",
            "flashinfer_cutedsl",
            "flashinfer_trtllm",
            "flashinfer_trtllm_routed",
            "deep_gemm",
        ], (
            "FlashInfer MoE A2A is supported with flashinfer_cutlass, "
            "flashinfer_cutedsl, flashinfer_trtllm, "
            "flashinfer_trtllm_routed, or deep_gemm."
        )

    if a2a_backend == "mori":
        is_epv2 = _resolve_mori_ep_v2(server_args)
        if cfg.deepep_mode == "auto":
            declare_resolution(
                server_args,
                "_handle_a2a_moe",
                deepep_mode="normal",
            )
            logger.warning("auto set deepep_mode=`normal` for MORI EP")
        elif is_epv2 and cfg.deepep_mode == "low_latency":
            declare_resolution(
                server_args,
                "_handle_a2a_moe",
                deepep_mode="normal",
            )
            logger.warning(
                "MORI EPv2 has no separate low-latency kernel; "
                "using deepep_mode=`normal` for deepep_mode=`low_latency`"
            )

        # Check chunked prefill for mori
        # Skip validation if chunked prefill is disabled (i.e., size <= 0).
        # Skip validation if disaggregation mode is decode.
        if cfg.chunked_prefill_size > 0 and cfg.disaggregation_mode != "decode":
            assert (
                required_mori_dispatch_tokens_per_rank(server_args)
            ) <= envs.SGLANG_MORI_NUM_MAX_DISPATCH_TOKENS_PER_RANK.get(), (
                "SGLANG_MORI_NUM_MAX_DISPATCH_TOKENS_PER_RANK (default 4096) "
                "must be >= the per-rank MoRI dispatch tokens "
                "(chunked_prefill_size by default)"
            )

    if a2a_backend == "pplx":
        if cfg.deepep_mode == "normal":
            raise ValueError(
                "moe_a2a_backend='pplx' only supports low-latency mode; "
                "set --deepep-mode to 'low_latency' or 'auto'."
            )
        if cfg.deepep_mode == "auto":
            declare_resolution(
                server_args,
                "_handle_a2a_moe",
                deepep_mode="low_latency",
            )
            logger.warning("auto set deepep_mode=`low_latency` for PPLX EP")
        # pplx-kernels' AllToAll needs numDPGroups (== attn_dp_size) > 1;
        # without DP attention numDPGroups == 1 and construction fails deep in
        # the kernel. This also implies ep_size >= 2.
        assert cfg.attn_dp_size >= 2, (
            "moe_a2a_backend='pplx' requires attention DP with at least 2 "
            "groups (--attn-dp-size >= 2)."
        )
        # pplx runs the masked DeepGEMM expert path (sm_90a): reject other
        # runners and resolve auto -> deep_gemm. Unquantized bf16 pplx needs
        # an explicit deep_gemm backend, otherwise the expert layer falls
        # through to the deprecated masked path and asserts at runtime.
        assert resolved_view(server_args).moe_runner_backend in ("deep_gemm", "auto"), (
            "moe_a2a_backend='pplx' is only supported with --moe-runner-backend "
            "deep_gemm (or auto)."
        )
        if cfg.moe_runner_backend == "auto":
            declare_resolution(
                server_args,
                "_handle_a2a_moe",
                moe_runner_backend="deep_gemm",
            )
            logger.warning("auto set moe_runner_backend=`deep_gemm` for PPLX EP")

        # Check per-rank dispatch tokens for pplx
        # Skip validation if chunked prefill is disabled (i.e., size <= 0)
        # Skip validation if disaggregation mode is decode
        if cfg.chunked_prefill_size > 0 and cfg.disaggregation_mode != "decode":
            assert (
                required_pplx_dispatch_tokens_per_rank(server_args)
            ) <= envs.SGLANG_PPLX_NUM_MAX_DISPATCH_TOKENS_PER_RANK.get(), (
                "SGLANG_PPLX_NUM_MAX_DISPATCH_TOKENS_PER_RANK (default 128) "
                "must be >= the per-rank pplx dispatch tokens "
                "(chunked_prefill_size, or the decode cuda-graph batch size)"
            )


def validate_deepep_v2_speculative_draft(server_args: Any) -> None:
    """Reject an explicit or inherited DeepEP v2 draft backend."""
    view = resolved_view(server_args)
    draft_backend = view.speculative_moe_a2a_backend
    if draft_backend is None and view.speculative_algorithm:
        from sglang.srt.speculative.spec_info import SpeculativeAlgorithm

        algorithm = SpeculativeAlgorithm.from_string(view.speculative_algorithm)
        if not algorithm.is_ngram():
            draft_backend = view.moe_a2a_backend
    if draft_backend == "deepep_v2":
        raise ValueError(
            "DeepEP v2 MoE is not validated as a speculative draft backend. "
            "Select another --speculative-moe-a2a-backend."
        )


def required_deepep_v2_prefill_tokens_per_rank(server_args: Any) -> int:
    """Largest prefill dispatch on one rank, after topology and model sharding."""
    view = resolved_view(server_args)
    ceiling = max_prefill_buffer_tokens(server_args) or (view.max_prefill_tokens or 0)
    # A per-DP chunk is scattered across tp_size // attn_dp_size ranks before
    # dispatch, so that is the per-EP-rank divisor (pure TP scatters across all).
    scatter_ranks = max(1, view.tp_size // view.attn_dp_size)
    return model_deepep_v2_prefill_dispatch_tokens(
        hf_config=model_config_of(server_args).hf_config,
        cfg=view,
        ceiling=ceiling,
        default_tokens=-(-ceiling // scatter_ranks),
    )


def _decode_graph_dispatch_tokens_per_rank(server_args: Any) -> tuple[int, int]:
    """(requests, tokens per request) of the largest decode/verify CUDA graph on
    one DP rank; (0, 1) when this instance captures no decode graph."""
    view = resolved_view(server_args)
    cg_config = view.cuda_graph_config
    if (
        view.disaggregation_mode == "prefill"
        or cg_config is None
        or cg_config.decode.backend == Backend.DISABLED
    ):
        return 0, 1
    graph_bs = cg_config.decode.max_bs or 0
    if view.max_running_requests is not None:
        per_rank_pool_bs = max(1, view.max_running_requests // view.attn_dp_size)
        graph_bs = min(graph_bs, per_rank_pool_bs)
    tokens_per_req = (
        max_speculative_num_draft_tokens(server_args) or 1
        if view.speculative_algorithm
        else 1
    )
    return graph_bs, tokens_per_req


def validate_deepep_v2_dispatch_token_budget(server_args: Any) -> None:
    """Check the configured prefill and decode-graph buffer bounds."""
    view = resolved_view(server_args)
    if view.moe_a2a_backend != "deepep_v2":
        return

    capacity = envs.SGLANG_DEEPEP_V2_NUM_MAX_DISPATCH_TOKENS_PER_RANK.get()
    if view.disaggregation_mode != "decode":
        prefill_tokens = required_deepep_v2_prefill_tokens_per_rank(server_args)
        if prefill_tokens > capacity:
            raise ValueError(
                "DeepEP v2 per-rank prefill budget exceeds "
                "SGLANG_DEEPEP_V2_NUM_MAX_DISPATCH_TOKENS_PER_RANK: "
                f"required={prefill_tokens}, capacity={capacity}. Raise the "
                "environment value or lower --chunked-prefill-size/"
                "--max-prefill-tokens."
            )

    graph_bs, tokens_per_req = _decode_graph_dispatch_tokens_per_rank(server_args)
    graph_tokens = graph_bs * tokens_per_req
    if graph_tokens > capacity:
        raise ValueError(
            "DeepEP v2 per-rank decode CUDA graph exceeds "
            "SGLANG_DEEPEP_V2_NUM_MAX_DISPATCH_TOKENS_PER_RANK: "
            f"required={graph_tokens}, capacity={capacity} "
            f"(requests={graph_bs}, tokens/request={tokens_per_req}). Raise "
            "the environment value or lower --cuda-graph-max-bs-decode."
        )


def validate_deepep_v2_model_architecture(server_args: Any) -> None:
    """Allow DeepEP v2 only for registered model architectures."""

    if (
        parse_connector_type(resolved_view(server_args).model_path)
        == ConnectorType.INSTANCE
    ):
        raise ValueError(
            "DeepEP v2 MoE cannot validate a model loaded through an instance "
            "connector. Load it from a model path or use "
            "--moe-a2a-backend deepep."
        )

    hf_config = model_config_of(server_args).hf_config
    if not model_supports_deepep_v2(hf_config):
        architectures = getattr(hf_config, "architectures", None) or []
        architecture = architectures[0] if architectures else None
        raise ValueError(
            f"DeepEP v2 MoE is not validated for {architecture!r}. The model "
            "package must register its architecture with "
            "register_deepep_v2_model, because its combine and post-expert "
            "reduction semantics must be validated first."
        )


def _required_flashinfer_a2a_dispatch_tokens_per_rank(server_args: Any) -> int:
    """Largest token count one DP rank dispatches through FlashInfer A2A in one
    forward: eager prefill chunks, prefill CUDA graphs, and decode/verify graphs.
    """
    view = resolved_view(server_args)
    tokens = 0
    cg_config = view.cuda_graph_config
    if view.disaggregation_mode != "decode":
        tokens = max_prefill_buffer_tokens(server_args)
        if cg_config is not None and cg_config.prefill.backend != Backend.DISABLED:
            tokens = max(tokens, cg_config.prefill.max_bs or 0)
    graph_bs, tokens_per_req = _decode_graph_dispatch_tokens_per_rank(server_args)
    return max(tokens, graph_bs * tokens_per_req)


def validate_flashinfer_a2a_token_budget(server_args: Any) -> None:
    """Fail fast if the per-rank FlashInfer A2A workspace cannot hold the
    largest forward; at runtime the dispatcher asserts on the first such batch."""
    view = resolved_view(server_args)
    if view.moe_a2a_backend != "flashinfer":
        return
    if view.disaggregation_mode != "decode" and view.chunked_prefill_size <= 0:
        raise ValueError(
            "FlashInfer MoE A2A requires chunked prefill: eager prefill "
            "dispatches the whole per-rank extend batch through a fixed-size "
            "workspace, so --chunked-prefill-size must be > 0."
        )

    required = _required_flashinfer_a2a_dispatch_tokens_per_rank(server_args)
    capacity = flashinfer_a2a_max_dispatch_tokens_per_rank(
        max_prefill_buffer_tokens(server_args)
    )
    if required > capacity:
        raise ValueError(
            "FlashInfer MoE A2A per-rank token budget exceeds its workspace: "
            f"required={required} tokens per rank (prefill chunk, prefill "
            f"graph, or decode/verify graph), capacity={capacity}. Set "
            f"SGLANG_FLASHINFER_NUM_MAX_DISPATCH_TOKENS_PER_RANK>={required}, "
            "or unset it to size from --chunked-prefill-size, or lower "
            "--chunked-prefill-size / the CUDA graph max batch sizes."
        )


def _resolve_mori_ep_v2(server_args: Any) -> bool:
    """Whether to use MORI EPv2.

    Unset prefers EPv2 and falls back to EPv1 where it is unsupported; an explicit
    true keeps EPv2 regardless, and false selects EPv1.
    """
    if not envs.SGLANG_MORI_EP_V2.get():
        return False

    reason = _mori_epv2_unsupported_reason(server_args)
    if reason is None:
        return True
    if envs.SGLANG_MORI_EP_V2.is_set():
        logger.warning(
            "SGLANG_MORI_EP_V2=true is set explicitly, so MORI EPv2 is used even "
            "though it does not support %s.",
            reason,
        )
        return True

    logger.warning(
        "MORI EPv2 does not support %s; falling back to MORI EPv1. "
        "Set SGLANG_MORI_EP_V2=true to force EPv2, or false to select EPv1.",
        reason,
    )
    # Worker processes inherit the env, so every reader agrees on EPv1.
    envs.SGLANG_MORI_EP_V2.set(False)
    return False


def _mori_epv2_unsupported_reason(server_args: Any) -> str | None:
    # The dispatcher falls back from unsupported dispatch/combine dtypes once it
    # knows the weight dtype.
    import torch

    from sglang.srt.configs.model_config import is_deepseek_v4

    cfg = resolved_view(server_args)
    # gfx1250 forms its LSA team from the UALink vPOD, which can span hosts and is
    # only known once cco is up, so init_mori_epv2_op checks that EP fits in it.
    if cfg.tp_size > 8 and not is_gfx1250_supported():
        return f"ep_size={cfg.tp_size} across hosts (EPv2 is validated within one host)"
    if not envs.SGLANG_USE_AITER.get():
        return "SGLANG_USE_AITER=0 (EPv2 experts run on the aiter MoE runner)"
    if get_bool_env_var("MORI_ENABLE_SDMA", "false"):
        return "MORI_ENABLE_SDMA=1 (SDMA is EPv1-only)"
    if parse_connector_type(cfg.model_path) == ConnectorType.INSTANCE:
        return "a model loaded through an instance connector (cannot validate it)"
    model_config = model_config_of(server_args)
    if model_config.dtype != torch.bfloat16:
        return f"dtype={model_config.dtype} (EPv2 requires bfloat16)"
    if not is_deepseek_v4(model_config.hf_config):
        architecture = (model_config.hf_config.architectures or [None])[0]
        return f"{architecture} (EPv2 is validated on DeepSeek-V4 only)"
    return None


def required_mori_dispatch_tokens_per_rank(server_args: Any) -> int:
    """Max tokens a single rank dispatches through MoRI in one forward."""
    cfg = resolving_view(server_args)
    return cfg.chunked_prefill_size


def required_pplx_dispatch_tokens_per_rank(server_args: Any) -> int:
    """Max tokens a single rank dispatches through pplx in one forward."""
    cfg = resolving_view(server_args)
    required = cfg.chunked_prefill_size
    if cfg.cuda_graph_max_bs_decode is not None:
        required = max(required, cfg.cuda_graph_max_bs_decode)
    return required
