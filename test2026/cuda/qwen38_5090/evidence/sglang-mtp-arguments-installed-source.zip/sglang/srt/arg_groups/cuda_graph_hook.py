# SPDX-License-Identifier: Apache-2.0
"""Server-argument resolution for the CUDA-graph capture configuration."""

from __future__ import annotations

import logging
from typing import Any, Optional

from sglang.srt.arg_groups.overrides import (
    attention_backends_of,
    declare_resolution,
    model_config_of,
    resolved_view,
    resolving_view,
)
from sglang.srt.connector import ConnectorType
from sglang.srt.model_executor.cuda_graph_config import (
    ALLOWED_BACKENDS_PER_PHASE,
    Backend,
    CudaGraphConfig,
    Phase,
    default_cuda_graph_config,
    with_phase,
)
from sglang.srt.utils.common import (
    parse_connector_type,
)

logger = logging.getLogger(__name__)


def parse_cuda_graph_config(server_args: Any):
    """Resolve cuda_graph_config from explicit JSON, per-phase
    convenience flags, legacy global flags, and defaults.
    Precedence (highest first): explicit JSON > convenience > legacy > defaults.
    Also populates server_args._cuda_graph_config_locked — the set of
    (phase, key) tuples that came from non-default sources; the
    auto-disable cascade respects this lock (an explicitly supplied prefill
    backend skips the cascade, whichever value it is).
    """
    cfg = resolving_view(server_args)
    raw_input = cfg.cuda_graph_config
    if isinstance(raw_input, CudaGraphConfig):
        explicit_input = raw_input.to_dict()
    else:
        explicit_input = raw_input or {}
    config = default_cuda_graph_config()
    locked: set = set()

    def _set(phase: str, key: str, value: Any) -> None:
        setattr(getattr(config, phase), key, value)
        locked.add((phase, key))

    # ---- Legacy global flags (lowest precedence above defaults) ----
    if cfg.disable_cuda_graph:
        _set(Phase.DECODE, "backend", Backend.DISABLED)
        _set(Phase.PREFILL, "backend", Backend.DISABLED)

    # ---- Boolean per-phase off-switches ----
    # Below the explicit backend selectors so --cuda-graph-backend-*
    # wins if both are given.
    if cfg.disable_prefill_cuda_graph:
        _set(Phase.PREFILL, "backend", Backend.DISABLED)
    if cfg.disable_decode_cuda_graph:
        _set(Phase.DECODE, "backend", Backend.DISABLED)

    # ---- Per-phase convenience flags ----
    if cfg.cuda_graph_backend_decode is not None:
        _set(Phase.DECODE, "backend", cfg.cuda_graph_backend_decode)
    if cfg.cuda_graph_backend_prefill is not None:
        _set(Phase.PREFILL, "backend", cfg.cuda_graph_backend_prefill)
    if cfg.cuda_graph_max_bs_decode is not None:
        _set(Phase.DECODE, "max_bs", cfg.cuda_graph_max_bs_decode)
    if cfg.cuda_graph_max_bs_prefill is not None:
        _set(Phase.PREFILL, "max_bs", cfg.cuda_graph_max_bs_prefill)
    if cfg.cuda_graph_max_seq_len_prefill is not None:
        _set(Phase.PREFILL, "max_seq_len", cfg.cuda_graph_max_seq_len_prefill)
    if cfg.cuda_graph_bs_decode is not None:
        _set(Phase.DECODE, "bs", cfg.cuda_graph_bs_decode)
    if cfg.cuda_graph_bs_prefill is not None:
        _set(Phase.PREFILL, "bs", cfg.cuda_graph_bs_prefill)
    if cfg.cuda_graph_prefill_max_context is not None:
        _set(
            Phase.PREFILL,
            "max_context_size",
            cfg.cuda_graph_prefill_max_context,
        )

    # ---- Explicit JSON config (highest precedence) ----
    for phase, phase_config in explicit_input.items():
        if not isinstance(phase_config, dict):
            continue
        for key, value in phase_config.items():
            _set(phase, key, value)

    declare_resolution(
        server_args,
        "_parse_cuda_graph_config",
        cuda_graph_config=config,
    )
    server_args._cuda_graph_config_locked = locked


def apply_cuda_graph_compatibility(server_args: Any):
    """Auto-disable prefill cuda graph for incompatible configs.
    Breakable and Full have different constraints. Skip automatic selection
    when the user explicitly sets the prefill backend.
    """

    cfg = resolving_view(server_args)
    if (Phase.PREFILL, "backend") in server_args._cuda_graph_config_locked:
        return

    # PP prefill graph replay is opt-in. It is most useful for small
    # aggregate forwards, while enabling it implicitly would also capture
    # large buckets that can be slower than eager. An explicit backend
    # selection bypasses this default policy.
    if cfg.pp_size > 1 and cfg.cuda_graph_config.prefill.backend == Backend.BREAKABLE:
        logger.info(
            "Disabling breakable prefill CUDA graph by default for pipeline "
            "parallelism. Set --cuda-graph-backend-prefill=breakable to opt in."
        )
        declare_resolution(
            server_args,
            "_apply_cuda_graph_compatibility",
            cuda_graph_config=with_phase(
                cfg.cuda_graph_config, Phase.PREFILL, backend=Backend.DISABLED
            ),
        )
        return

    if cfg.cuda_graph_config.prefill.backend == Backend.BREAKABLE:
        disable_breakable_cudagraph_if_incompatible(server_args)
    elif cfg.cuda_graph_config.prefill.backend == Backend.FULL:
        disable_full_prefill_cudagraph_if_incompatible(server_args)


def disable_breakable_cudagraph_if_incompatible(server_args: Any):
    """Breakable (segmented capture, no torch.compile). Breakable enforces
    memory-saver rejection in its own __init__; config-time rules can be
    added here as they're discovered.
    """

    cfg = resolving_view(server_args)
    from sglang.srt.configs.model_config import (
        is_deepseek_v4,
        uses_kda_attention,
    )
    from sglang.srt.layers.cp.bcg import supports_prefill_cp_bcg

    rules = [
        (
            "KDA hybrid linear attention",
            # GLM-5.3 Flash is BCG-validated; other KDA models stay off by default.
            lambda: (
                uses_kda_attention(model_config_of(server_args).hf_config)
                and "Glm5NextForConditionalGeneration"
                not in model_config_of(server_args).hf_config.architectures
            ),
        ),
        # DSV4 is BCG-compatible but introduces heavy memory pressure: the
        # c4 indexer scratch is pinned in the capture pool and OOMs. Disable.
        (
            "DeepSeek-V4 (heavy capture-pool memory pressure)",
            lambda: is_deepseek_v4(model_config_of(server_args).hf_config),
        ),
        # CP all_gather replay size mismatch under BCG.
        (
            "context parallel (attn_cp_size > 1)",
            lambda: (
                resolved_view(server_args).attn_cp_size > 1
                and not supports_prefill_cp_bcg(server_args)
            ),
        ),
        # Capture builds a dummy extend forward with attn_dcp_metadata=None.
        (
            "decode context parallel (dcp_size > 1)",
            lambda: cfg.dcp_size > 1,
        ),
        # TBO capture is unsupported.
        (
            "two-batch overlap",
            lambda: cfg.enable_two_batch_overlap,
        ),
        (
            "unvalidated a2a backend",
            lambda: (
                resolved_view(server_args).moe_a2a_backend
                not in ("none", "deepep", "megamoe", "flashinfer")
            ),
        ),
        # Multimodal prefill replay faults under BCG; allowlisted archs opt back in.
        (
            "multimodal model",
            lambda: (
                model_config_of(server_args).is_multimodal
                and not model_config_of(
                    server_args
                ).is_multimodal_breakable_cuda_graph_supported
            ),
        ),
    ]
    for name, predicate in rules:
        if predicate():
            logger.warning(
                "Breakable CUDA graph is incompatible with %s; "
                "disabling prefill CUDA graph.",
                name,
            )
            declare_resolution(
                server_args,
                "_disable_breakable_cudagraph_if_incompatible",
                cuda_graph_config=with_phase(
                    cfg.cuda_graph_config, Phase.PREFILL, backend=Backend.DISABLED
                ),
            )
            return


def disable_full_prefill_cudagraph_if_incompatible(server_args: Any):
    """Full prefill CG: empty rule list today; see the experimental warning."""
    cfg = resolving_view(server_args)
    rules = []
    for name, predicate in rules:
        if predicate():
            logger.warning(
                "Full prefill CUDA graph is incompatible with %s; "
                "disabling prefill CUDA graph.",
                name,
            )
            declare_resolution(
                server_args,
                "_disable_full_prefill_cudagraph_if_incompatible",
                cuda_graph_config=with_phase(
                    cfg.cuda_graph_config, Phase.PREFILL, backend=Backend.DISABLED
                ),
            )
            return


def disable_prefill_cuda_graph_for_deepseek_trtllm_mla(server_args: Any):
    """Disable prefill CUDA graph for dsr1 by default when using the trtllm_mla
    attention backend. Under any captured prefill CUDA graph trtllm_mla falls back to FlashAttention for prefill and regresses
    performance, so disable whichever prefill graph backend is in effect.
    """

    cfg = resolving_view(server_args)

    if (Phase.PREFILL, "backend") in server_args._cuda_graph_config_locked:
        return
    if cfg.cuda_graph_config.prefill.backend == Backend.DISABLED:
        return
    if (
        "DeepseekV3ForCausalLM"
        not in model_config_of(server_args).hf_config.architectures
    ):
        return
    prefill_attention_backend, _ = attention_backends_of(resolved_view(server_args))
    if prefill_attention_backend != "trtllm_mla":
        return
    logger.warning(
        "Disabling prefill CUDA graph (%s) by default for the DeepSeek-V3 arch on "
        "the trtllm_mla attention backend (a captured prefill graph forces a "
        "FlashAttention fallback that regresses prefill). Set the prefill cuda graph "
        "backend explicitly (e.g. --cuda-graph-backend-prefill breakable) to override.",
        cfg.cuda_graph_config.prefill.backend,
    )
    declare_resolution(
        server_args,
        "_disable_prefill_cuda_graph_for_deepseek_trtllm_mla",
        cuda_graph_config=with_phase(
            cfg.cuda_graph_config, Phase.PREFILL, backend=Backend.DISABLED
        ),
    )


def apply_deepep_adjustments(server_args: Any):
    """Config adjustments required by the DeepEP a2a backend."""
    cfg = resolving_view(server_args)
    if resolved_view(server_args).moe_a2a_backend != "deepep":
        return

    # Non-multiple-of-8 prefill buckets can hang DeepEP a2a capture under
    # breakable CUDA graph
    if cfg.cuda_graph_config.prefill.backend == Backend.BREAKABLE:
        bs = cfg.cuda_graph_config.prefill.bs
        if bs is None:
            # 2048 = documented prefill default; max_bs unresolved here.
            max_bs = cfg.cuda_graph_config.prefill.max_bs or 2048
            bs = generate_prefill_cuda_graph_batch_sizes(max_bs)
        aligned = sorted({((b + 7) // 8) * 8 for b in bs})
        if aligned != sorted(bs):
            logger.info(
                "Breakable prefill CUDA graph with DeepEP requires bucket "
                "sizes divisible by 8; aligning %s -> %s.",
                sorted(bs),
                aligned,
            )
            declare_resolution(
                server_args,
                "_apply_deepep_adjustments",
                cuda_graph_config=with_phase(
                    cfg.cuda_graph_config,
                    Phase.PREFILL,
                    bs=aligned,
                    max_bs=aligned[-1],
                ),
            )


def apply_inkling_prefill_cuda_graph_default(server_args: Any):
    """Inkling opts into full-graph prefill CUDA-graph capture. Must run
    before _handle_cuda_graph_config: the generic breakable default is
    auto-disabled for this multimodal arch, and declarative model overrides
    materialize too late to steer cuda-graph resolution. Honors an explicit
    --cuda-graph-backend-prefill / --disable-prefill-cuda-graph."""

    cfg = resolving_view(server_args)
    if (
        cfg.cuda_graph_backend_prefill is not None
        or cfg.disable_prefill_cuda_graph
        or parse_connector_type(cfg.model_path) == ConnectorType.INSTANCE
    ):
        return
    arch = model_config_of(server_args).hf_config.architectures[0]
    if arch in (
        "InklingForConditionalGeneration",
        "InklingForConditionalGenerationMTP",
    ):
        declare_resolution(
            server_args,
            "_apply_inkling_prefill_cuda_graph_default",
            cuda_graph_backend_prefill=Backend.FULL,
        )


def apply_muse_glimmer_prefill_cuda_graph_max_bs_default(server_args: Any):

    cfg = resolving_view(server_args)
    if (
        cfg.cuda_graph_max_bs_prefill is not None
        or parse_connector_type(cfg.model_path) == ConnectorType.INSTANCE
    ):
        return
    arch = model_config_of(server_args).hf_config.architectures[0]
    if arch in ("MuseGlimmerForCausalLM", "MuseGlimmerForConditionalGeneration"):
        declare_resolution(
            server_args,
            "_apply_muse_glimmer_prefill_cuda_graph_max_bs_default",
            cuda_graph_max_bs_prefill=512,
        )


def handle_cuda_graph_config(server_args: Any):
    cfg = resolving_view(server_args)

    parse_cuda_graph_config(server_args)
    apply_cuda_graph_compatibility(server_args)
    apply_deepep_adjustments(server_args)
    apply_cuda_graph_disaggregation_roles(server_args)
    validate_cuda_graph_config(server_args)
    # Warn on the final resolved config (not inside the compat cascade —
    # that path is skipped when the user explicitly sets the backend,
    # which is the only way to get 'full' for prefill today).
    if cfg.cuda_graph_config.prefill.backend == Backend.FULL:
        logger.warning(
            "cuda_graph_config[prefill].backend='full' is experimental. "
            "Use breakable for production workloads."
        )


def validate_cuda_graph_config(server_args: Any):
    cfg = resolving_view(server_args)
    if cfg.cuda_graph_config is None:
        return
    for phase in Phase.ALL:
        backend = getattr(cfg.cuda_graph_config, phase).backend
        if backend not in ALLOWED_BACKENDS_PER_PHASE[phase]:
            raise ValueError(
                f"--cuda-graph-config[{phase}].backend={backend!r} not allowed; "
                f"allowed: {ALLOWED_BACKENDS_PER_PHASE[phase]}"
            )


def _resolve_max_context_size(
    *, requested_size: Any, page_size: int, model_context_len: Optional[int]
) -> int:
    if requested_size <= 0:
        raise ValueError("--cuda-graph-prefill-max-context must be a positive integer")

    aligned_size = int((requested_size + page_size - 1) // page_size * page_size)
    if (
        model_context_len is not None
        and model_context_len > 0
        and aligned_size > model_context_len
    ):
        raise ValueError(
            "--cuda-graph-prefill-max-context exceeds the model context length: "
            f"aligned size {aligned_size} > {model_context_len}"
        )
    if requested_size != aligned_size:
        logger.info(
            "Page-aligning prefill CUDA graph max context size %d -> %d "
            "(page_size=%d).",
            requested_size,
            aligned_size,
            page_size,
        )
    return aligned_size


def finalize_cuda_graph_prefill_max_context(server_args: Any) -> None:
    cfg = resolving_view(server_args)
    requested_size = cfg.cuda_graph_config.prefill.max_context_size
    if requested_size is None:
        return
    page_size = cfg.page_size
    assert page_size is not None and page_size > 0, (
        "page_size must be resolved before prefill CUDA graph max context size"
    )

    max_context_size = _resolve_max_context_size(
        requested_size=requested_size,
        page_size=page_size,
        model_context_len=model_config_of(server_args).context_len,
    )
    logger.info(
        "Prefill CUDA graph max context size: %d; graph keys remain token-only.",
        max_context_size,
    )
    declare_resolution(
        server_args,
        "_finalize_cuda_graph_prefill_max_context",
        cuda_graph_config=with_phase(
            cfg.cuda_graph_config,
            Phase.PREFILL,
            max_context_size=max_context_size,
        ),
    )


def generate_prefill_cuda_graph_batch_sizes(max_bs: int):
    """
    Generate the list of batch sizes for prefill CUDA graph capture
    based on max_bs. For prefill, bs carries the
    captured token count (one shape knob per phase).
    """
    capture_sizes = (
        list(range(4, 33, 4))
        + list(range(48, 257, 16))
        + list(range(288, 513, 32))
        + list(range(576, 1024 + 1, 64))
        + list(range(1280, 4096 + 1, 256))
        + list(range(4608, max_bs + 1, 512))
    )

    capture_sizes = [s for s in capture_sizes if s <= max_bs]

    return capture_sizes


def generate_decode_cuda_graph_batch_sizes(server_args: Any, max_bs: int):
    """
    Generate the list of batch sizes for CUDA graph capture based on max_bs.
    This integrates the logic from cuda_graph_runner.py.
    """
    cfg = resolving_view(server_args)
    # Handle disable_cuda_graph_padding as the first condition for both spec and non-spec
    if cfg.disable_cuda_graph_padding:
        capture_bs = list(range(1, max_bs + 1))
    elif cfg.speculative_algorithm is None:
        # Normal case:
        capture_bs = (
            [1, 2, 4, 8, 12]
            + list(range(16, 257, 8))
            + list(range(272, 512, 16))
            + list(range(512, max_bs + 1, 32))
        )
    else:
        # Spec decoding case: less padding for smaller batch sizes
        capture_bs = (
            list(range(1, 9, 1))
            + list(range(10, 33, 2))
            + list(range(40, 65, 4))
            + list(range(72, 257, 8))
            + list(range(272, max_bs + 1, 16))
        )

    capture_bs = [bs for bs in capture_bs if bs <= max_bs]

    if max_bs not in capture_bs:
        capture_bs.append(max_bs)

    return capture_bs


def generate_cpu_graph_batch_sizes(server_args: Any):
    """
    Generate the list of batch sizes for CPU graph capture based on torch_compile_max_bs.
    """
    cfg = resolving_view(server_args)
    if cfg.disable_cuda_graph_padding:
        capture_bs = list(range(1, cfg.torch_compile_max_bs + 1))
    else:
        capture_bs = sorted(
            set().union(
                range(1, 17),
                range(18, 31, 2),
                range(32, 81, 4),
                range(84, cfg.torch_compile_max_bs + 1, 8),
                {cfg.torch_compile_max_bs},
            )
        )
    capture_bs = [bs for bs in capture_bs if bs <= cfg.torch_compile_max_bs]

    return capture_bs


def apply_cuda_graph_disaggregation_roles(server_args: Any):
    cfg = resolving_view(server_args)
    if cfg.disaggregation_mode == "prefill":
        if (Phase.DECODE, "backend") not in server_args._cuda_graph_config_locked:
            declare_resolution(
                server_args,
                "_apply_cuda_graph_disaggregation_roles",
                cuda_graph_config=with_phase(
                    cfg.cuda_graph_config, Phase.DECODE, backend=Backend.DISABLED
                ),
            )
    elif cfg.disaggregation_mode == "decode":
        if (Phase.PREFILL, "backend") not in server_args._cuda_graph_config_locked:
            declare_resolution(
                server_args,
                "_apply_cuda_graph_disaggregation_roles",
                cuda_graph_config=with_phase(
                    cfg.cuda_graph_config, Phase.PREFILL, backend=Backend.DISABLED
                ),
            )
