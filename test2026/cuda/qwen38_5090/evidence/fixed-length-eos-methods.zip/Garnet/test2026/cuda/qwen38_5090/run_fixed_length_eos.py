"""One supervised actual EOS-policy ordinary/MTP regression; no timing benchmark."""
from pathlib import Path
import hashlib,json,os,shutil,sys,time,zipfile
ROOT=Path('D:/CantorAI/5090-study-20261023');REPO=ROOT/'Garnet';M=REPO/'test2026/cuda/qwen38_5090';sys.path.insert(0,str(M))
from run_logged import run
from run_bf16_low_batch_native_build import idle
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
NAME='fixed-length-eos-consistency-attempt1';OUT=ROOT/'results'/NAME
p_path=M/'evidence/fixed-length-eos-preparation.json';p=json.loads(p_path.read_bytes());archive=ROOT/'results'/(NAME+'-evidence.zip');assert not OUT.exists() and not archive.exists()
for name,digest in p['files'].items():assert sha(ROOT/name)==digest,('Source/input drift',name)
for name,digest in p['runtime_dependencies'].items():assert sha(ROOT/'build/bin'/name)==digest,('Runtime drift',name)
for name,parent in p['parents'].items():
 proof=ROOT/'results'/(name+'-verified.json');q=json.loads(proof.read_bytes());closed=json.loads((ROOT/'results'/name/'workflow.json').read_bytes());assert sha(proof)==parent['proof_sha256'] and q['status']==parent['status'] and sha(ROOT/'results'/(name+'-evidence.zip'))==parent['archive_sha256'] and closed['cleanup_finished']
library=ROOT/'build/bin/garnet.dll';digest=sha(library);assert digest==sha(ROOT/'build/bin/garnet-native-tokenizer-nfc-attempt1.dll')
receipt=ROOT/'results/study-ssd-engine-cache/receipt.json';cache=Path(json.loads(receipt.read_bytes())['cache_root']);assert cache.resolve().drive.upper()=='C:' and json.loads((cache/'study-owner.json').read_bytes())['study']==str(ROOT) and shutil.disk_usage(cache).free>=96*1024**3
def retire(before,started):
 resolved=cache.resolve(strict=True);assert json.loads((cache/'study-owner.json').read_bytes())['study']==str(ROOT);retired=[]
 for target in cache.iterdir():
  if target.name in before or not target.name.startswith('garnet-cuda-graph-'):continue
  st=target.lstat();assert not(getattr(st,'st_file_attributes',0)&0x400) and target.resolve(strict=True).parent==resolved and st.st_ctime>=started-2
  entries=list(target.iterdir());assert all(f.name in ('model.engine','model.engine.tmp') for f in entries)
  for f in entries:
   fs=f.lstat();assert f.is_file() and not(getattr(fs,'st_file_attributes',0)&0x400) and f.resolve(strict=True).parent==target.resolve(strict=True)
   h=hashlib.sha256()
   with f.open('rb') as stream:
    for block in iter(lambda:stream.read(8<<20),b''):h.update(block)
   retired.append({'path':str(f),'bytes':fs.st_size,'sha256':h.hexdigest()})
  for f in entries:f.unlink()
  target.rmdir()
 return retired

idle();OUT.mkdir();os.chdir(REPO);code=1;w={'status':'running','preparation_sha256':sha(p_path),'source_sha256':p['files'],'runtime_dependencies':p['runtime_dependencies'],'parents':p['parents'],'library_sha256':digest,'variants':[],'cleanup_finished':False,'performance_admitted':False,'scope':p['scope']}
def save():(OUT/'workflow.json').write_text(json.dumps(w,indent=2),encoding='utf8')
common=[ROOT/name for name in p['files']]+[p_path,receipt];save()
try:
 code=run([sys.executable,'-m','unittest','test2026.cuda.qwen38_5090.test_fixed_length_worker_contract','test2026.cuda.qwen38_5090.test_fixed_length_native_stream','test2026.cuda.qwen38_5090.test_fixed_length_reference','test2026.cuda.qwen38_5090.test_mmmu_http_quality','test2026.cuda.qwen38_5090.test_mmmu_quality_protocol'],OUT/'cpu-ledger','correctness','43CPU fixed-length/default-restore/ID/usage/quality controls',common)
 if code:raise RuntimeError('Fixed-length CPU controls failed')
 for mode in ('ordinary','mtp'):
  idle();before={f.name for f in cache.iterdir()};started=time.time();entry={'mode':mode,'finished':False};w['variants'].append(entry);save()
  try:
   command=[sys.executable,str(M/'monitor_native_probe.py'),'--study',str(ROOT),'--output',str(OUT/(mode+'-resources')),'--',sys.executable,str(M/'probe_fixed_length_eos.py'),'--root',str(ROOT),'--mode',mode,'--output',str(OUT/mode)]
   if mode=='mtp':command+=['--ordinary',str(OUT/'ordinary')]
   code=run(command,OUT/(mode+'-ledger'),'correctness','Actual4K natural74/forced128/natural74restore/forced128SSE '+mode,common+[library]);entry.update(finished=True,exit_code=code);save()
   if code:raise RuntimeError('Fixed-length EOS correctness failed: '+mode)
  finally:idle();entry['retired_private_engine_files']=retire(before,started);save()
 w['status']='fixed_length_eos_collected_needs_replay'
except BaseException as error:w.update(status='failed',error=repr(error));code=code or 1;raise
finally:
 w.update(exit_code=code,source_after_sha256={name:sha(ROOT/name) for name in p['files']},runtime_dependencies_after={name:sha(ROOT/'build/bin'/name) for name in p['runtime_dependencies']},library_unchanged=sha(library)==digest);save();idle();w['cleanup_finished']=True;save()
 paths=[f for f in OUT.rglob('*') if f.is_file()]+common;raw={f.relative_to(ROOT).as_posix():f.read_bytes() for f in paths}
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
  for name,data in raw.items():z.writestr(name,data)
  z.writestr('evidence-manifest.json',json.dumps({'files':{name:hashlib.sha256(data).hexdigest() for name,data in raw.items()},'scope':p['scope']},indent=2))
 print(json.dumps({'status':w['status'],'archive_sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(raw)}),flush=True)
raise SystemExit(code)
