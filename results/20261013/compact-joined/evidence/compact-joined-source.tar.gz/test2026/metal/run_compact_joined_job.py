"""Durable, exclusive validation job for compact joined-half storage."""
import json, subprocess, sys, time
from pathlib import Path

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
if '--worker' not in sys.argv:
    out.mkdir(parents=True, exist_ok=False)
    with (out/'output.log').open('w') as stream:
        process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), str(root), str(out), '--worker'],
                                   stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid': process.pid}))
    print(json.dumps({'pid': process.pid, 'output': str(out)}))
else:
    begin = time.monotonic()
    code = 1
    try:
        code = subprocess.call([sys.executable, str(root/'source/test2026/metal/run_compact_joined_checks.py'), str(root), str(out/'jobs')])
    finally:
        (out/'exit.json').write_text(json.dumps({'exit_code': code, 'wall_seconds': time.monotonic()-begin}))
    sys.exit(code)
